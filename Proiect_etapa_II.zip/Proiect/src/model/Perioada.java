package model;

public enum Perioada {
    CLASICA,
    ANTEBELICA,
    INTERBELICA,
    POSTBELICA
}
